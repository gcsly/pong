###########################
#		         #
#  HOW TO PLAY PONG GAME  #
#  CREATED BY LINDA HAN   #
#		         #
###########################

---------------------------
PROJECT FILES

main.py (run this file to start game)
paddle.py
ball.py

To be used with the latest versions of Python (3.9.6) and Pygame (1.8.1).
Please ensure that all project files reside in the same directory.

See users' manual for more information on how to play Pong. Enjoy.